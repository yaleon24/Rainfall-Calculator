#include <iostream>
#include <stdlib.h>

using namespace std;
///////////////////////////////////prototypes//////////////////////////////////////////////////////////////
void sortRainfall(double a[], string b[], int c);
void getRainfall();
///////////////////////////////////arrays////////////////////////////////////////////////////////////////
string months[12] {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
double rainfall[12] {}, rainfall_total = 0;
////////////////////////////////////////main//////////////////////////////////////////////////////////
int main()
{

    cout << "Please enter the inches of rainfall for the following months: \n";
    getRainfall();
    cout << "\nThe total rainfall for the year was " << rainfall_total << " inches.\n";
    cout << "The average monthly rainfall is " << rainfall_total/12 << " inches.\n";
    sortRainfall(rainfall,months,12);
    cout << "The highest rainfall occurred in " << months[11] << " at " << rainfall[11] << " inches.\n";
    cout << "The lowest rainfall occurred in " << months[0] << " at " << rainfall[0] << " inches.\n";
    cout << "The rainfall from highest to lowest is: \n";
    for (int i = 11; i >= 0; i--)
        cout << months[i] << ": " << rainfall[i] << " inches\n";
    return 0;
}
//////////////////////////////////////display///////////////////////////////////////////////////
void getRainfall()
{
//fill in rainfall array in this method.  Display below if the user tries to enter negative numbers.
    for(int i=0; i<=11; i++)
    {
        cout << months[i] << ": ";
        cin>>rainfall[i];
        if(rainfall[i]<0)
        {
            cout << "You cannot enter negative numbers.\n";
            break;
        }
        rainfall_total+=rainfall[i];
    }
}
/////////////////////////////sorting ///////////////////////////////////////////////////////////
void sortRainfall(double rainfall[], string months[], int length)
{

//use the sorting algorithms from the presentation to sort the rainfall and months array
    int start, minindex, minvalue;
    string mmonths;
    for(start=0; start<(length-1); start++)
    {
        minindex=start;
        minvalue=rainfall[start];
        mmonths=months[start];

        for(int index=start+1; index<length; index++)
        {
            if(rainfall[index]<minvalue)
            {
                minvalue=rainfall[index];
                minindex=index;
                mmonths=months[index];
            }
        }
        rainfall[minindex]=rainfall[start];
        rainfall[start]=minvalue;
        months[minindex]=months[start];
        months[start]=mmonths;
    }
}
